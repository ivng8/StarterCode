export interface ITypeErrors {

    getMessage(): string;
}